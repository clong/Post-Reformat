#!/bin/bash
set -euo pipefail

bundle_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
theme_name='iTerm2 Screenshot Match'
theme_file="$bundle_dir/$theme_name"
bundled_cli='/Applications/Rex.app/Contents/Helpers/Rex Server.rex/Contents/MacOS/rex'
installed_cli="$HOME/Library/Application Support/com.superlogical.rex/RexServer/Versions/Current/Rex Server.app/Contents/MacOS/rex"

if rex_bin=$(command -v rex); then
    :
elif [[ -x "$installed_cli" ]]; then
    rex_bin=$installed_cli
elif [[ -x "$bundled_cli" ]]; then
    rex_bin=$bundled_cli
else
    printf '%s\n' 'Install and open Rex, then run this script again.' >&2
    exit 1
fi

if [[ ! -r "$theme_file" ]]; then
    printf 'Missing theme file: %s\n' "$theme_file" >&2
    exit 1
fi

rex_action() {
    if ! "$rex_bin" --autostart=false do "$@" --json >/dev/null; then
        printf 'Rex could not run %s. Check that Rex is open and Remote Control is enabled.\n' "$1" >&2
        return 1
    fi
}

# Use the existing theme ID on repeat runs to avoid importing duplicates.
existing_theme=$(
    /usr/bin/defaults export com.superlogical.rex - 2>/dev/null |
        /usr/bin/plutil -extract 'Workspace\.customThemes' raw -o - - 2>/dev/null |
        /usr/bin/base64 -D 2>/dev/null |
        /usr/bin/perl -MJSON::PP -e '
            local $/;
            my $json = <STDIN>;
            exit unless defined $json && length $json;
            my $themes = eval { decode_json($json) };
            exit unless ref $themes eq "ARRAY";
            for my $theme (reverse @$themes) {
                next unless ($theme->{name} // "") eq $ARGV[0];
                next unless ($theme->{appearance} // "") eq "dark";
                print $theme->{id} // "";
                last;
            }
        ' "$theme_name" || true
)

rex_action client.setting.interface.appearance.scheme value=dark
if [[ -n "$existing_theme" ]]; then
    rex_action client.setting.themes.dark.palette "value=$existing_theme"
else
    rex_action client.theme.import "path=$theme_file"
fi

rex_action client.setting.themes.dark.extended_palette value=true
rex_action client.setting.terminal.colors.palette value=false
rex_action client.setting.terminal.colors.contrast value=false

rex_action client.setting.terminal.typography.font 'value=MesloLGS NF'
rex_action client.setting.terminal.typography.style value=Regular
rex_action client.setting.terminal.typography.size value=14
rex_action client.setting.terminal.advanced_fonts.bold_italic value=both
rex_action client.setting.terminal.advanced_fonts.smoothing value=true
rex_action client.setting.terminal.cursor.style value=block
rex_action client.setting.terminal.cursor.blink value=off

rex_action client.setting.interface.appearance.style value=classic
rex_action client.setting.interface.appearance.tint value=false
rex_action client.setting.interface.appearance.glass value=false
rex_action client.setting.interface.tabs.shell_icon_theme value=default
rex_action client.setting.interface.panes.density value=comfortable
rex_action client.setting.interface.panes.headers value=always_show
rex_action client.setting.interface.pane_padding.horizontal value=5
rex_action client.setting.interface.pane_padding.vertical value=3
rex_action client.setting.interface.pane_padding.program_background value=false
rex_action client.setting.interface.active_panes.active_border value=false
rex_action client.setting.interface.active_panes.fade value=both
rex_action client.setting.interface.active_panes.inactive_window value=false

printf '%s\n' 'Rex appearance restored. Check Terminal → Typography for MesloLGS NF at 14 pt.'
