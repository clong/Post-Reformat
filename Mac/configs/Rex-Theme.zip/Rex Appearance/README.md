# Restore the Rex appearance on macOS

1. If MesloLGS NF is missing, open the four `.ttf` files in `Fonts` with Font Book and install them.
2. Open Rex. In **Settings → General → Client Info**, turn on **Remote Control** for setup.
3. Open a terminal in this folder and run `/bin/bash ./restore-rex-appearance.sh`. You can turn Remote Control off again after setup.

If more than one Rex app is connected, run `rex client ls` to find this Mac’s client label. Then run `REX_CLIENT=your-label /bin/bash ./restore-rex-appearance.sh`.

The script selects the theme by name if it already exists. Otherwise, it imports the bundled `iTerm2 Screenshot Match` theme file.

## Set up through Rex Settings

Use these values if you prefer to configure Rex by hand or if a future release renames a CLI action.

| Settings section | Values |
| --- | --- |
| Themes | Import `iTerm2 Screenshot Match`, select it under Dark Mode, and enable **Use extended theme palette**. |
| Interface → Appearance | Dark color scheme, Classic style, and Tint with Theme off. |
| Interface → Panes | Comfortable spacing and Always Show headers. Under Customize Panes, set Padding X to 5 and Padding Y to 3. Turn off **Include pane header** under Padding. |
| Interface → Active Pane | Turn off the active pane highlight. Set **Fade inactive panes** to Both and turn off **Fade panes for inactive windows**. |
| Interface → Tabs | Set Shell Icon Color to the default shell icon. |
| Terminal → Typography | MesloLGS NF, Regular, 14 pt. Under Advanced Font Settings, enable bold and italic rendering and turn on Font Smoothing. |
| Terminal → Colors | Turn off Improve Text Contrast and Force Theme Palette for Text. |
| Terminal → Cursor | Block cursor with blinking off. |

Powerlevel10k supplies the prompt layout and clock. The Rex theme supplies the colors used by that prompt.

[Rex settings reference](https://www.superlogical.com/rex/docs/reference/mac-settings)

The bundled fonts are the four [MesloLGS NF faces from Powerlevel10k](https://github.com/romkatv/powerlevel10k/blob/master/font.md), with their license notices in `Fonts`.
